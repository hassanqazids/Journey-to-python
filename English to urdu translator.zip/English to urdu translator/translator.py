import speech_recognition as sr
from googletrans import Translator
from gtts import gTTS
import pygame
import os
recognizer = sr.Recognizer()
translator = Translator()
print("Spaeak something in English")
with sr.Microphone() as source:
    recognizer.adjust_for_ambient_noise(source)
    audio = recognizer.listen(source)
try:
    english_text = recognizer.recognize_google(audio)
    print(" You said (English):", english_text)
    urdu_text = translator.translate(english_text, src='en', dest='ur').text
    print("🌐 Translated to Urdu:", urdu_text)
    tts = gTTS(text=urdu_text, lang='ur')
    audio_file = "urdu_audio.mp3"
    tts.save(audio_file)
    pygame.mixer.init()
    pygame.mixer.music.load(audio_file)
    pygame.mixer.music.play()
    while pygame.mixer.music.get_busy():
        pass
    os.remove(audio_file)
except sr.UnknownValueError:
    print("Could not understand your speech.")
except sr.RequestError:
    print(" Could not reach the recognition service.")
    # project made by wania khan 
    